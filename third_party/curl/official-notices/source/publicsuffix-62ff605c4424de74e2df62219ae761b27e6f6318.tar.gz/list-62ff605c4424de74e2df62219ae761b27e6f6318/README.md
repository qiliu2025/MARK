# The Public Suffix List

A "public suffix" is one under which Internet users can (or historically could)
directly register names. Some examples of public suffixes are `com`, `co.uk` and
`pvt.k12.ma.us`. The Public Suffix List is a list of all known public suffixes.

See https://publicsuffix.org/ and the [Wiki](https://github.com/publicsuffix/list/wiki) link above for more information.

## Are you here to add or update something?

All submissions must conform to the [validation and acceptance factors](https://github.com/publicsuffix/list/wiki/Guidelines#validation-and-non-acceptance-factors), provide sufficient rationale, and be as complete as possible, following the [Guidelines](https://github.com/publicsuffix/list/wiki/Guidelines), especially as they relate to format and [sorting](https://github.com/publicsuffix/list/wiki/Guidelines#sort-your-submission-correctly-important).

The list is currently maintained by people who are volunteering their time towards universal acceptance and ensuring there is a bridge between the ICANN world of domain names and the crucial last mile - the world of developers and human users.

Iteration back and forth will delay PR review or inclusion. Be extremely thorough and patient.

## Important Notices

### 2026-05-06
Pull Requests MUST use the automated template when adding.  Do not cut and paste it into a GPT to generate a response or delete / alter the form. Pull requests that do not use the template, that alter it or summarize it will be closed by volunteers without action.  Why?  There are specific checkboxes that are part of the volunteers' review or are important attestations for public record and transparency and consistency of processing. 

### 2025-05-27
Were you directed here to be able to add a subdomain to your **Cloudflare** account? If so, please work directly with Cloudflare for these account limitations. The PSL is **NOT** intended as a workaround for Cloudflare's subdomain restrictions. 

Consult [Cloudflare's subdomain setup documentation](https://developers.cloudflare.com/dns/zone-setups/subdomain-setup/) or contact Cloudflare directly for subdomain setup questions. Only submit a request to the PSL if your domain truly meets our criteria outlined in [Guidelines](https://github.com/publicsuffix/list/wiki/Guidelines).

### 2024-07-26
We are sending emails asking for confirmation if certain entries are still required or need updating.

Currently, this process is purely manual and extremely low volume, but if you do get an email, please respond.

Please see the [Email Communication Policy](#email-communication-policy) to see how we will often communicate these changes.

### 2023-02-20
Did [guidance from Google related to the changes that they are making to AdSense subdomains](https://support.google.com/adsense/answer/12170421) bring you here? Work with Google AdSense [Help Link](https://support.google.com/adsense/gethelp) with any support questions you have. The PSL is thinly resourced, and the volunteer maintainers are unable to answer questions about Adsense changes or support Adsense.

The PSL is volunteer-resourced and is absolutely not resourced to answer questions or support changes. Guidance is in the form of self-help (READ THE [WIKI](https://github.com/publicsuffix/list/wiki)), THERE IS NO PSL CUSTOMER SERVICE RESOURCE TO ASSIST YOU. *Please work directly with Google to ensure your domain does in fact need an entry, and they should help you know what the benefits and consequences are. __IT IS POSSIBLE TO HARM YOUR WEBSITE COOKIES BY REQUESTING A MALFORMED PSL ENTRY__. Also, understand what propagation delays and rollback processing entail before making requests.*

### 2021-04-23
Did guidance related to an issue with Facebook or Apple bring you here? [Read this before submitting requests](https://github.com/publicsuffix/list/issues/1245). We are not approving workaround requests per the validation and acceptance standards, but we do have open discussions with Facebook on the matter.

## Email Communication Policy

We tend to use the subject line tag "[PSL notification]" in all Public Suffix List communications. For effective spam filtering, you can create a case-insensitive filter to allow only emails with the exact "[PSL notification]" in the subject line. If you choose to set up such a filter in your email application, please verify the filter is implemented correctly and test it thoroughly to ensure you don't accidentally miss important communications from us.

## Code of Conduct

Your participation in the Public Suffix List project should follow the [Mozilla Community Participation Guidelines](https://www.mozilla.org/en-US/about/governance/policies/participation/ "Mozilla Community Participation Guidelines") as well as the [GitHub Community Participation Guidelines](https://help.github.com/en/github/site-policy/github-community-guidelines "GitHub Community Participation Guidelines"). Behavior that falls into the areas forbidden by either document is unwelcome and will result in further escalation.
